package com.incedo.firstspringdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstSpringDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstSpringDemoApplication.class, args);
	}

}
