package com.incedo.firstspringdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSpringDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
